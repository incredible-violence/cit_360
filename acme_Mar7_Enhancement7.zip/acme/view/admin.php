<?php
session_start();
if (!$_SESSION['loggedin']) {
    $_SESSION['message'] = "<p>SOMEONE'S TRYING TO BE NAUGHTY! BAD! BAD USER! LOOK AT WHAT YOU DID!</p>";
    header('Location: /acme/');
}

if (isset($_SESSION['message'])) {
 $message = $_SESSION['message'];
}
?><!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta charset='utf-8'>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="ACME">
        <link rel='stylesheet' href='/acme/css/normalize.css'>
        <link rel='stylesheet' href='/acme/css/main.css'>
        <link rel='stylesheet' href='/acme/css/medium.css'>
        <link rel='stylesheet' href='/acme/css/large.css'>
        <link rel='stylesheet' href='/acme/css/hom.css'>
        <link rel='stylesheet' href='/acme/css/forms.css'>
        <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Smokum" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=NTR" rel="stylesheet">

        <title>ACME</title>
    </head>
    <body>
        <div id='whitebackground'>
            <!-- HEADER -->
            <header>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/header.php'; ?>
            </header>

            <!-- NAVIGATION -->
            <nav>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/nav.php'; ?>
            </nav>

            <!-- MAIN -->
            <main class="site-content">
                <h1><?php echo $_SESSION['clientData']['clientFirstname'] . ' ' . $_SESSION['clientData']['clientLastname']; ?>&nbsp;Logged In</h1>
                <?php
                if (isset($message)) {
                    echo $message;
                }
                ?>
                <div id='updateAcctLink'>
                    <a href="/acme/accounts/index.php?action=updateAcct"><div class="btn">Update Information</div></a>
                   
                </div>
                <div id='productLink'>
                    <?php
                    if ($_SESSION['clientData']['clientLevel'] > 1) {
                        echo "<h4>Use this Link for Product Administration</h4>";
                        echo "<a href='/acme/products/'><div class='btnadmin'>Products Page</div></a>";
                    }
                    ?>
                </div>
            </main>

            <!-- FOOTER -->

            <footer>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/footer.php'; ?>
            </footer>
        </div>
        <script src='/acme/scripts/toggleMenu.js'></script>
    </body>
</html>


