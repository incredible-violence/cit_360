<?php
session_start();

if ($_SESSION['clientData']['clientLevel'] < 2) {
    header('Location: /acme/');
} 
?><!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta charset='utf-8'>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="ACME">
        <link rel='stylesheet' href='/acme/css/normalize.css'>
        <link rel='stylesheet' href='/acme/css/main.css'>
        <link rel='stylesheet' href='/acme/css/medium.css'>
        <link rel='stylesheet' href='/acme/css/large.css'>
        <link rel='stylesheet' href='/acme/css/forms.css'>
        <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Smokum" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=NTR" rel="stylesheet">
        <title>ACME</title>
    </head>
    <body>
        <div id="whitebackground">
            <!-- HEADER -->
            <header>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/header.php'; ?> 
            </header>

            <!-- NAVIGATION -->
            <nav>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/nav.php'; ?>
            </nav>

            <!-- MAIN -->
            <main>
                
                <?php
                if (isset($message)) {
                    echo $message;
                }
                ?>
                <form id="newCatForm" method="post" action="/acme/products/index.php">
                    <div class="loginForm">
                        <h1>Add a Category</h1>
                        <input type="text" name="categoryName" value="" required/>
                        <a href="/acme/view/product-management.php"><div class="btn">Cancel</div></a>
                        <button type="submit" form="newCatForm" id="regbtn" name="submit" value="new_category_in">Add Category</button>
                        <input type="hidden" name="action" value="new_category_in">
                    </div>
                </form>
            </main>

            <!-- FOOTER -->
            <footer>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/footer.php'; ?>
            </footer>
        </div>
        <script src='/acme/scripts/toggleMenu.js'></script>
    </body>
</html>