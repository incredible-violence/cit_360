<?php
session_start();
?><!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta charset='utf-8'>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="ACME">
        <link rel='stylesheet' href='/acme/css/normalize.css'>
        <link rel='stylesheet' href='/acme/css/main.css'>
        <link rel='stylesheet' href='/acme/css/medium.css'>
        <link rel='stylesheet' href='/acme/css/large.css'>
        <link rel='stylesheet' href='/acme/css/forms.css'>
        <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Smokum" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=NTR" rel="stylesheet">
        <title>ACME</title>
    </head>
    <body>
        <div id="whitebackground">
            <!-- HEADER -->
            <header>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/header.php'; ?> 
            </header>

            <!-- NAVIGATION -->
            <nav>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/nav.php'; ?>
            </nav>

            <!-- MAIN -->
            <main>
                <?php
                if (isset($message)) {
                    echo $message;
                }
                ?>
                <form id="regForm" method="post" action="/acme/accounts/index.php">
                    <div class="loginForm" >
                        <h1>Register</h1>
                        <fieldset>
                            <legend>First Name</legend>
                            <input type="text" name="clientFirstname" <?php if(isset($clientFirstname)){echo "value='$clientFirstname'";} ?> class="login" placeholder="first name" required/>
                        </fieldset>
                        <fieldset>
                            <legend>Last Name</legend>
                            <input type="text" name="clientLastname" <?php if(isset($clientLastname)){echo "value='$clientLastname'";} ?> class="login" placeholder="last name" required/>
                        </fieldset>
                        <fieldset>
                            <legend>Email</legend>
                            <input type="email" name="clientEmail" <?php if(isset($clientEmail)){echo "value='$clientEmail'";} ?> class="login" placeholder="email" required/>
                        </fieldset>
                        <fieldset>
                            <legend>Password*</legend>
                            <input type="password" name="clientPassword" value="" class="login" placeholder="password" pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" required/>
                        </fieldset>
                        <!--
                        <fieldset>
                            <legend>Confirm Password</legend>
                            <input type="password" name="clientPasswordConfirm" value="" class="login" placeholder="confirm password"/>
                        </fieldset>
                        -->
                        <a href="/acme/accounts/index.php?action=login"><button class="btn">Sign In</button></a>
                        <a href="#"><button type="submit" form="regForm" id="regbtn" name="submit" value="register_user">Sign Up</button></a>
                        <input type="hidden" name="action" value="register_user">
                    </div>
                </form>
                <br><div class="asterisks">*Password should be at least 8 characters and have at least 1 uppercase letter, 1 number, and 1 special character</div><br>
            </main>

            <!-- FOOTER -->
            <footer>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/footer.php'; ?>
            </footer>
        </div>
        <script src='/acme/scripts/toggleMenu.js'></script>
    </body>
</html>
