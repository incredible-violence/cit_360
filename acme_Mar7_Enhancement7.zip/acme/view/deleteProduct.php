<?php
// session_start();

if ($_SESSION['clientData']['clientLevel'] < 2) {
    header('Location: /acme/');
}
// 
?>
<!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta charset='utf-8'>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="ACME">
        <link rel='stylesheet' href='/acme/css/normalize.css'>
        <link rel='stylesheet' href='/acme/css/main.css'>
        <link rel='stylesheet' href='/acme/css/medium.css'>
        <link rel='stylesheet' href='/acme/css/large.css'>
        <link rel='stylesheet' href='/acme/css/forms.css'>
        <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Smokum" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=NTR" rel="stylesheet">
        <title><?php if (isset($prodInfo['invName'])) {
    echo "Delete $prodInfo[invName]";
} ?> | Acme, Inc.</title>
    </head>
    <body>
        <div id="whitebackground">
            <!-- HEADER -->
            <header>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/header.php'; ?> 
            </header>

            <!-- NAVIGATION -->
            <nav>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/nav.php'; ?>
            </nav>

            <!-- MAIN -->
            <main>
                <!-- ERROR MESSAGE AREA -->
                <?php
                if (isset($message)) {
                    echo $message;
                }
                ?>
                <!-- ADD PRODUCT FORM -->
                <div id="form" class="newProductForm">
                    <h1><?php if (isset($prodInfo['invName'])) {
                    echo "Delete $prodInfo[invName]";
                } ?></h1> 
                    <form id="deleteProdForm" action="/acme/products/index.php" method="post">
                        <div class="formGroup">
                            <label for="invName">Name: </label>
                            <input type="text" name="invName" id="invName" readonly <?php if (isset($invName)) { echo "value='$invName'";} elseif (isset($prodInfo['invName'])) {echo "value='$prodInfo[invName]'";} ?>>
                        </div>
                        <div class="formGroup">
                            <label for="invDescription">Description: </label>
                            <input type="text" name="invDescription" id="invDescription" <?php if (isset($invDescription)) { echo "value='$invDescription'";  } elseif (isset($prodInfo['invDescription'])) {echo "value='$prodInfo[invDescription]'";} ?> readonly />
                        </div>
                        <div class="formGroup">
                            <a href="/acme/products"><div class="btn">CANCEL</div></a>
                            <button type="submit" form="deleteProdForm" id="regbtn" name="submit" value="deleteProd">DELETE</button>
                            <input type="hidden" name="action" value="deleteProd">
                            <input type="hidden" name="invId" value="<?php if (isset($prodInfo['invId'])) {echo $prodInfo['invId'];} elseif (isset($invId)) {echo $invId;} ?>">
                        </div>
                        <div class="formGroup">
                        <p>WARNING: DELETION IS PERMANENT!</p> 
                        </div>
                    </form>
                </div>
            </main>

            <!-- FOOTER -->
            <footer>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/footer.php'; ?>
            </footer>
        </div>
        <script src='/acme/scripts/toggleMenu.js'></script>
    </body>
</html>