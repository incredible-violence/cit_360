<?php
session_start();
if (!$_SESSION['loggedin']) {
    $_SESSION['message'] = "<p>SOMEONE'S TRYING TO BE NAUGHTY! BAD! BAD USER! LOOK AT WHAT YOU DID!</p>";
    header('Location: /acme/');
}

if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    // $_SESSION['message'] = "";
}
?><!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta charset='utf-8'>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="ACME">
        <link rel='stylesheet' href='/acme/css/normalize.css'>
        <link rel='stylesheet' href='/acme/css/main.css'>
        <link rel='stylesheet' href='/acme/css/medium.css'>
        <link rel='stylesheet' href='/acme/css/large.css'>
        <link rel='stylesheet' href='/acme/css/hom.css'>
        <link rel='stylesheet' href='/acme/css/forms.css'>
        <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Smokum" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=NTR" rel="stylesheet">

        <title>ACME</title>
    </head>
    <body>
        <div id='whitebackground'>
            <!-- HEADER -->
            <header>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/header.php'; ?>
            </header>

            <!-- NAVIGATION -->
            <nav>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/nav.php'; ?>
            </nav>

            <!-- MAIN -->
            <main class="site-content">
                <h1>Update Account Information:&nbsp;<?php echo $_SESSION['clientData']['clientFirstname'] . ' ' . $_SESSION['clientData']['clientLastname']; ?></h1>
                <?php
                if (isset($message)) {
                    echo $message;
                }
                ?>

                <div id="form1">
                    <h3>Update Information</h3>
                    <form id="updateAcctForm" action="/acme/accounts/index.php" method="post">
                        <div class="formGroup">
                            <label for="clientFirstname">First Name: </label>
                            <input type="text" name="clientFirstname" id="clientFirstname" value="<?php echo $_SESSION['clientData']['clientFirstname'] ?>" required >
                        </div>
                        <div class="formGroup">
                            <label for="clientLastname">Last Name: </label>
                            <input type="text" name="clientLastname" id='clientLastname' value="<?php echo $_SESSION['clientData']['clientLastname'] ?>" required >
                        </div>
                        <div class="formGroup">
                            <label for="clientEmail">Email: </label>
                            <input type="text" name="clientEmail" id="clientEmail" value="<?php echo $_SESSION['clientData']['clientEmail'] ?>" required > 
                        </div>
                        <div class="formGroup">
                            <a href="/acme/accounts"><div class="btn">Cancel</div></a>
                            <button type="submit" form="updateAcctForm" id="regbtn" name="submit" value="updateAcct">Update</button>
                            <input type="hidden" name="action" value="updateInfo">
                            <input type="hidden" name="clientId" value="<?php echo $_SESSION['clientData']['clientId'] ?>">
                        </div>
                    </form>
                </div>

                <div id="form2">
                    <h3>Update Password</h3>
                    <form id="updatePassForm" action="/acme/accounts/index.php" method="post">
                        <div class="formGroup">
                            <label for="clientPassword">New Password: </label>
                            <input type="password" name="clientPassword" id="clientPassword" value="" pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" required >

                        </div>
                        <div class="formGroup">
                            <a href="/acme/accounts"><div class="btn">Cancel</div></a>
                            <button type="submit" form="updatePassForm" id="regbtn" name="submit" value="updatePassword">Update</button>
                            <input type="hidden" name="clientId" value="<?php echo $_SESSION['clientData']['clientId'] ?>">
                            <input type="hidden" name="action" value="updatePassword">
                        </div>
                    </form>
                </div>
                <br><div class="asterisks">*Password should be at least 8 characters and have at least 1 uppercase letter, 1 number, and 1 special character</div><br>

            </main>

            <!-- FOOTER -->

            <footer>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/footer.php'; ?>
            </footer>
        </div>
        <script src='/acme/scripts/toggleMenu.js'></script>
    </body>
</html>


