<?php
session_start();
?><!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta charset='utf-8'>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="ACME">
        <link rel='stylesheet' href='/acme/css/normalize.css'>
        <link rel='stylesheet' href='/acme/css/main.css'>
        <link rel='stylesheet' href='/acme/css/medium.css'>
        <link rel='stylesheet' href='/acme/css/large.css'>
        <link rel='stylesheet' href='/acme/css/hom.css'>
        <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Smokum" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=NTR" rel="stylesheet">

        <title>ACME</title>
    </head>
    <body>
        <div id='whitebackground'>
            <!-- HEADER -->
            <header>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/header.php'; ?>
            </header>

            <!-- NAVIGATION -->
            <nav>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/nav.php'; ?>
            </nav>

            <!-- MAIN -->
            <main class="site-content">
                <h1>WELCOME TO ACME</h1>

                <div class="rocketpic">
                    <img src='/acme/images/site/rocketfeature.jpg' alt="rocket">
                    <h2>Acme Rocket</h2>
                    <ul>    
                        <li>Quick Lighting Fuse</li>
                        <li>NHTSA approved seat belts</li>
                        <li>Mobile launch stand included</li>
                        <li><a href="#" id='iwantit'><img src='/acme/images/site/iwantit.gif' alt='iwantit' id='actionBtn'></a>
                    </ul>
                </div>

                <section class='reviewSection'>
                    <div class='reviews'>
                        <ul>
                            <li><h3>Acme Rocket Reviews</h3></li>
                            <li>"I don't know how I ever caught roadrunners before this." (4/5)</li>
                            <li>"That thing was fast!" (4/5)</li>
                            <li>"Talk about fast delivery." (5/5)</li>
                            <li>"I didn't even have to pull the meat apart." (4.5/5)</li>
                            <li>"I'm on my thirtieth one. I love these things!" (5/5)</li>
                        </ul>
                    </div>
                </section>

                <section class='recipeSection'>
                    <div class='recipes'>
                        <h3>Featured Recipes</h3>
                        <table>
                            <tr>
                                <td><img src="/acme/images/recipes/bbqsand.jpg" alt="bbq"></td>
                                <td><img src="/acme/images/recipes/potpie.jpg" alt="pot"></td>
                            </tr>
                            <tr>
                                <td><a href="#">Pulled Roadrunner BBQ</a></td>
                                <td><a href="#">Roadrunner Pot Pie</a></td>
                            </tr>
                            <tr>
                                <td><img src="/acme/images/recipes/soup.jpg" alt="soup"></td>
                                <td><img src="/acme/images/recipes/taco.jpg" alt="taco"></td>
                            </tr>
                            <tr>
                                <td><a href="#">Roadrunner Soup</a></td>
                                <td><a href="#">Roadrunner Tacos</a></td>
                            </tr>
                        </table>
                    </div>
                </section>
            </main>

            <!-- FOOTER -->
            <footer>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/footer.php'; ?>
            </footer>
        </div>
        <script src='/acme/scripts/toggleMenu.js'></script>
    </body>
</html>
