<!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta charset='utf-8'>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="ACME">
        <link rel='stylesheet' href='/acme/css/normalize.css'>
        <link rel='stylesheet' href='/acme/css/main.css'>
        <link rel='stylesheet' href='/acme/css/medium.css'>
        <link rel='stylesheet' href='/acme/css/large.css'>
        <link rel='stylesheet' href='/acme/css/forms.css'>
        <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Smokum" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=NTR" rel="stylesheet">
        <title>ACME</title>
    </head>
    <body>
        <div id="whitebackground">
            <!-- HEADER -->
            <header>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/header.php'; ?> 
            </header>

            <!-- NAVIGATION -->
            <nav>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/nav.php'; ?>
            </nav>

            <!-- MAIN -->
            <main>
                <?php
                if (isset($_SESSION['message'])) {
                    echo $_SESSION['message'];
                }

                //if (isset($message)) {
                //   echo $message;
                //}
                ?>
                <form id="logForm" method="post" action="/acme/accounts/index.php">
                    <div class="box">
                        <h1>Sign In</h1>
                        <input type="email" name="clientEmail" placeholder="username@email.com" <?php
                            if (isset($clientEmail)) {
                                echo "value='$clientEmail'";
                            }
                            ?> class="email" required/>
                        <input type="password" name="clientPassword" placeholder="P@ssw0rd" class="email" pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" required/>
                        <input type="submit" class="btn1" value="Sign In"/>
                        <input type="hidden" name="action" value="login_user"/>
                        <a href="/acme/accounts/index.php?action=register_form"><div id="regbtn">Sign Up</div></a>
                    </div> <!-- End Box -->
                </form>
               
                <br><div class="asterisks">*Password should be at least 8 characters and have at least 1 uppercase letter, 1 number, and 1 special character</div><br>
            </main>

            <!-- FOOTER -->
            <footer>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/footer.php'; ?>
            </footer>
        </div>
        <script src='/acme/scripts/toggleMenu.js'></script>
    </body>
</html>
