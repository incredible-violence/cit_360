<?php
session_start();

if ($_SESSION['clientData']['clientLevel'] < 2) {
    header('Location: /acme/');
} 
?><?php
$catList = '<select name="categoryId" id="categoryId">';
$catList .= "<option>Choose a Category</option>";
foreach ($categories as $key => $value) {
 $catList .= "<option value='" . ($key + 1) . "'>" . urlencode($value['categoryName']) . "</option>";
  if(isset($categoryId)){
   if(($key + 1) === $categoryId){
   $catList .= ' selected ';
  }
 } elseif(isset($prodInfo['categoryId'])){
  if($category['categoryId'] === $prodInfo['categoryId']){
   $catList .= ' selected ';
  }
}
$catList .= ">$value[categoryName]</option>";
}
$catList .= '</select>';
?>
<!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta charset='utf-8'>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="ACME">
        <link rel='stylesheet' href='/acme/css/normalize.css'>
        <link rel='stylesheet' href='/acme/css/main.css'>
        <link rel='stylesheet' href='/acme/css/medium.css'>
        <link rel='stylesheet' href='/acme/css/large.css'>
        <link rel='stylesheet' href='/acme/css/forms.css'>
        <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Smokum" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=NTR" rel="stylesheet">
        <title>ACME</title>
    </head>
    <body>
        <div id="whitebackground">
            <!-- HEADER -->
            <header>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/header.php'; ?> 
            </header>

            <!-- NAVIGATION -->
            <nav>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/nav.php'; ?>
            </nav>

            <!-- MAIN -->
            <main>
                <!-- ERROR MESSAGE AREA -->
                <?php
                if (isset($message)) {
                    echo $message;
                }
                ?>

                <!-- ADD PRODUCT FORM -->
                <div id="form" class="newProductForm">
                    <form id="newProdForm" action="/acme/products/index.php" method="post">
                        <h1>Add a Product</h1>

                        <div class="formGroup">
                            <label for="catList">Category: </label>
                            <?php echo $catList; ?>
                        </div>
                        <div class="formGroup">
                            <label for="invName">Name: </label>
                            <input type="text" name="invName" id="invName" <?php if(isset($invName)){echo "value='$invName'";} ?> required/>
                        </div>
                        <div class="formGroup">
                            <label for="invDescription">Description: </label>
                            <input type="text" name="invDescription" id="invDescription" <?php if(isset($invDescription)){echo "value='$invDescription'";} ?> required/>
                        </div>
                        <div class="formGroup">
                            <label for="invImage">Image Path: </label>
                            <input type="text" name="invImage" id="invImage" value="/acme/images/no-image.png" required/>
                        </div>
                        <div class="formGroup">
                            <label for="invThumbnail">Thumbnail: </label>
                            <input type="text" name="invThumbnail" id="invThumbnail" value="/acme/images/no-image.png" required/>
                        </div>
                        <div class="formGroup">
                            <label for="invPrice">Price: </label>
                            <input type="text" name="invPrice" id="invPrice" <?php if(isset($invPrice)){echo "value='$invPrice'";} ?>required/>
                        </div>
                        <div class="formGroup">
                            <label for="invStock">Stock: </label>
                            <input type="text" name="invStock" id="invStock" <?php if(isset($invStock)){echo "value='$invStock'";} ?> required/>
                        </div>
                        <div class="formGroup">
                            <label for="invSize">Size: </label>
                            <input type="text" name="invSize" id="invSize" <?php if(isset($invSize)){echo "value='$invSize'";} ?> required/>
                        </div>
                        <div class="formGroup">
                            <label for="invWeight">Weight: </label>
                            <input type="text" name="invWeight" id="invWeight" <?php if(isset($invWeight)){echo "value='$invWeight'";} ?> required/>
                        </div>
                        <div class="formGroup">
                            <label for="invLocation">Location: </label>
                            <input type="text" name="invLocation" id="invLocation" <?php if(isset($invLocation)){echo "value='$invLocation'";} ?> required/>
                        </div>
                        <div class="formGroup">
                            <label for="invVendor">Vendor: </label>
                            <input type="text" name="invVendor" id="invVendor" <?php if(isset($invVendor)){echo "value='$invVendor'";} ?> required/>
                        </div>
                        <div class="formGroup">
                            <label for="invStyle">Style: </label>
                            <input type="text" name="invStyle" id="invStyle" <?php if(isset($invStyle)){echo "value='$invStyle'";} ?> required/>
                        </div>
                       <a href="/acme/products/"><div class="btn">Cancel</div></a>
                        <button type="submit" form="newProdForm" id="regbtn" name="submit" value="new_product_in">Add Product</button>
                        <input type="hidden" name="action" value="new_product_in">
                    </form>
                </div>
            </main>

            <!-- FOOTER -->
            <footer>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/footer.php'; ?>
            </footer>
        </div>
        <script src='/acme/scripts/toggleMenu.js'></script>
    </body>
</html>