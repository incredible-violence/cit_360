function toggleMenu() {
 document.getElementById('navBar').classList.toggle('hide');
}
