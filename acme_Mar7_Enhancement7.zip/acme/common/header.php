
<div class='logo'>
    <figure>
        <img src='/acme/images/site/logo.gif' alt='logo' id='logo'>
    </figure>
</div>
<div class='welcome'>
    <?php
    if (isset($cookieFirstname)) {
        echo "<span>Welcome, $cookieFirstname</span>";
    }
    ?>
</div>
<div class='account'>
    <?php
    if ($_SESSION['loggedin']) {
        echo "<figure>
        <a href='/acme/accounts/index.php?action=logout'><img border='0' src='/acme/images/site/account.gif' alt='folder'></a>
    </figure>
    <p>Log Out</p>";
    }
    else {
        echo "<figure>
        <a href='/acme/accounts/index.php?action=login'><img border='0' src='/acme/images/site/account.gif' alt='folder'></a>
    </figure>
    <p>My Account</p>";
    }
    ?>
    
</div>

