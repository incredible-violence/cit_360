<!-- DYNAMIC VERSION -->
<?php 
echo $navList;