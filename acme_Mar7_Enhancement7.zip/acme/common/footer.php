<section class="footer-bar">&copy;&nbsp;ACME | All Rights Reserved | James Kennedy
</section>
<section class="footer-bar">All images used are believed to be in "Fair Use." Please Notify the author if any are not and they will be removed.
</section>
<section class="footer-bar">Last Updated:&nbsp;
    <?php
        echo date("d / m / Y")
    ?>
</section>
