<html>
    <head>
        <meta charset='utf-8'>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="ACME">
        <link rel='stylesheet' href='/acme/css/normalize.css'>
        <link rel='stylesheet' href='/acme/css/main.css'>
        <link rel='stylesheet' href='/acme/css/medium.css'>
        <link rel='stylesheet' href='/acme/css/large.css'>
        <link rel='stylesheet' href='/acme/css/forms.css'>
        <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Smokum" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=NTR" rel="stylesheet">
        <title>ACME</title>
    </head>
    <body>
        <div id="whitebackground">
            <!-- HEADER -->
            <header>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/header.php'; ?> 
            </header>

            <!-- NAVIGATION -->
            <nav>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/nav.php'; ?>
            </nav>

            <!-- MAIN -->
            <main>
                <?php
                if (isset($message)) {
                    echo $message;
                }
                ?>
            </main>

            <!-- FOOTER -->
            <footer>
                <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/footer.php'; ?>
            </footer>
        </div>
        <script src='scripts/toggleMenu.js'></script>
    </body>
</html>