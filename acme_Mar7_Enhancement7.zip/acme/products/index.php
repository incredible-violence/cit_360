<?php

/*
 * Products Controller
 */

// create or access a session
session_start();

// Get the database connection file
require_once '../library/connections.php';
// Get the acme model for use as needed
require_once '../model/acme-model.php';
// get the products model
require_once '../model/products-model.php';
// get the functions
require_once '../library/functions.php';

// Get the array of category Names
$categories = getCategories();

// $navList = createNav($categories);
$navList = createNav($categories);

// echo $navList;
// exit;
// CATEGORY LIST
//$catList = '<select name="categoryId" id="categoryId">';
//$catList .= "<option value='default'>Choose a Category</option>";
//foreach ($categories as $key => $value) {
//    $catList .= "<option value='" . ($key + 1) . "'>" . urlencode($value['categoryName']) . "</option>";
//}
//$catList .= "</select>";

$action = filter_input(INPUT_POST, 'action');
if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
}

switch ($action) {
    case "new_category_in":
        // filter input
        $categoryName = filter_input(INPUT_POST, 'categoryName', FILTER_SANITIZE_STRING);

        // check for missing
        if (empty($categoryName)) {
            $message = '<p>Please Enter a Category</p>';
            include '../view/addCategory.php';
            exit;
        }

        // send to model
        $catOutcome = newCategory($categoryName);

        // check and report result
        if ($catOutcome == 1) {
            $message = "<p>New Category $categoryName added.</p>";
            include '../view/addCategory.php';
            exit;
        } else {
            $message = "<p>Failed to add New Category $categoryName.</p>";
            include '../view/addCategory.php';
            exit;
        }

        break;
    case "new_category_form":
        include "../view/addCategory.php";
        break;
    case "new_product_in":
        // echo "New Product In Form";
        // filter
        $categoryId = filter_input(INPUT_POST, 'categoryId', FILTER_VALIDATE_INT);
        $invName = filter_input(INPUT_POST, 'invName', FILTER_SANITIZE_STRING);
        $invDescription = filter_input(INPUT_POST, 'invDescription', FILTER_SANITIZE_STRING);
        $invImage = filter_input(INPUT_POST, 'invImage', FILTER_SANITIZE_STRING);
        $invThumbnail = filter_input(INPUT_POST, 'invThumbnail', FILTER_SANITIZE_STRING);
        $invPrice = filter_input(INPUT_POST, 'invPrice', FILTER_VALIDATE_FLOAT);
        $invStock = filter_input(INPUT_POST, 'invStock', FILTER_VALIDATE_INT);
        $invSize = filter_input(INPUT_POST, 'invSize', FILTER_VALIDATE_INT);
        $invWeight = filter_input(INPUT_POST, 'invWeight', FILTER_VALIDATE_INT);
        $invLocation = filter_input(INPUT_POST, 'invLocation', FILTER_SANITIZE_STRING);
        $invVendor = filter_input(INPUT_POST, 'invVendor', FILTER_SANITIZE_STRING);
        $invStyle = filter_input(INPUT_POST, 'invStyle', FILTER_SANITIZE_STRING);

        // check for missing values
        if (empty($categoryId)) {
            $message .= '<p>Please Choose a Category</p>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invName)) {
            $message .= '<p>Please enter a Name</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invDescription)) {
            $message .= '<p>Please enter a Description</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invImage)) {
            $message .= '<p>Please enter an Image Path</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invThumbnail)) {
            $message .= '<p>Please enter a Thumbnail</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invPrice)) {
            $message .= '<p>Please enter a Price</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invStock)) {
            $message .= '<p>Please enter a Stock Amount</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invSize)) {
            $message .= '<p>Please enter a Size</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invWeight)) {
            $message .= '<p>Please enter a Weight</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invLocation)) {
            $message .= '<p>Please enter a Location</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invVendor)) {
            $message .= '<p>Please enter a Vendor</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invStyle)) {
            $message .= '<p>Please enter a Style</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }

        // send to model
        $npOutcome = newProduct($invName, $invDescription, $invImage, $invThumbnail, $invPrice, $invStock, $invSize, $invWeight, $invLocation, $categoryId, $invVendor, $invStyle);

        // check and report
        if ($npOutcome == 1) {
            $message = "<p>New Product $invName added.</p>";
            include '../view/updateProduct.php';
            exit;
        } else {
            $message = "<p>Failed to add New Product $invName.</p>";
            include '../view/updateProduct.php';
            exit;
        }
        break;
    case "new_product_form":
        include "../view/addProduct.php";
        break;
    case 'mod':
        $invId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        $prodInfo = getProductInfo($invId);
        // echo $prodInfo;
        // echo $prodInfo[1];
        if (count($prodInfo) < 1) {
            $message = 'Sorry, no product information could be found.';
        }
        include '../view/updateProduct.php';
        exit;
        break;

    case 'updateProd':
        // filter
        $categoryId = filter_input(INPUT_POST, 'categoryId', FILTER_VALIDATE_INT);
        $invName = filter_input(INPUT_POST, 'invName', FILTER_SANITIZE_STRING);
        $invDescription = filter_input(INPUT_POST, 'invDescription', FILTER_SANITIZE_STRING);
        $invImage = filter_input(INPUT_POST, 'invImage', FILTER_SANITIZE_STRING);
        $invThumbnail = filter_input(INPUT_POST, 'invThumbnail', FILTER_SANITIZE_STRING);
        $invPrice = filter_input(INPUT_POST, 'invPrice', FILTER_VALIDATE_FLOAT);
        $invStock = filter_input(INPUT_POST, 'invStock', FILTER_VALIDATE_INT);
        $invSize = filter_input(INPUT_POST, 'invSize', FILTER_VALIDATE_INT);
        $invWeight = filter_input(INPUT_POST, 'invWeight', FILTER_VALIDATE_INT);
        $invLocation = filter_input(INPUT_POST, 'invLocation', FILTER_SANITIZE_STRING);
        $invVendor = filter_input(INPUT_POST, 'invVendor', FILTER_SANITIZE_STRING);
        $invStyle = filter_input(INPUT_POST, 'invStyle', FILTER_SANITIZE_STRING);

        $invId = filter_input(INPUT_POST, 'invId', FILTER_SANITIZE_NUMBER_INT);

        // echo $categoryId . " ";
        // echo $invName . " ";
        // echo $invDescription . " ";
        // echo $invImage . " ";
        // echo $invThumbnail . " ";
        // echo $invPrice . " ";
        // echo $invStock . " ";
        // echo $invSize . " ";
        // echo $invWeight . " ";
        // echo $invLocation . " ";
        // echo $invVendor . " ";
        // echo $invStyle . " ";
        // echo $invId;
        // check for missing values
        if (empty($categoryId)) {
            $message .= '<p>Please Choose a Category</p>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invName)) {
            $message .= '<p>Please enter a Name</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invDescription)) {
            $message .= '<p>Please enter a Description</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invImage)) {
            $message .= '<p>Please enter an Image Path</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invThumbnail)) {
            $message .= '<p>Please enter a Thumbnail</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invPrice)) {
            $message .= '<p>Please enter a Price</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invStock)) {
            $message .= '<p>Please enter a Stock Amount</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invSize)) {
            $message .= '<p>Please enter a Size</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invWeight)) {
            $message .= '<p>Please enter a Weight</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invLocation)) {
            $message .= '<p>Please enter a Location</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invVendor)) {
            $message .= '<p>Please enter a Vendor</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }
        if (empty($invStyle)) {
            $message .= '<p>Please enter a Style</p><br/>';
            include '../view/updateProduct.php';
            exit;
        }

        // send to model
        $updateResult = updateProduct($categoryId, $invName, $invDescription, $invImage, $invThumbnail, $invPrice, $invStock, $invSize, $invWeight, $invLocation, $invVendor, $invStyle, $invId);

        // echo $updateResult;
        // check and report
        if ($updateResult) {
            echo $updateResult;
            echo "SUCCESS";
            $message = "<p>Product $invName Updated.</p>";
            $_SESSION['message'] = $message;
            header('location: /acme/products/');
            //include '/acme/products/';
            exit;
        } else {
            echo $updateResult;
            echo "FAILED";
            $message = "<p>Failed to Update $invName.</p>";
            $_SESSION['message'] = $message;
            header('location: /acme/products/');
            // include '/acme/products/';
            exit;
        }
        break;

    case 'del':
        $invId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        $prodInfo = getProductInfo($invId);
        // echo $prodInfo;
        // echo $prodInfo[1];
        if (count($prodInfo) < 1) {
            $message = 'Sorry, no product information could be found.';
        }
        include '../view/deleteProduct.php';
        exit;
        break;
    case 'deleteProd':
        // variables
        $invName = filter_input(INPUT_POST, 'invName', FILTER_SANITIZE_STRING);
        $invId = filter_input(INPUT_POST, 'invId', FILTER_SANITIZE_NUMBER_INT);

        // send to model
        $deleteResult = deleteProduct($invId);

        // check and report
        if ($deleteResult) {
            $message = "<p>Product $invName Deleted.</p>";
            $_SESSION['message'] = $message;
            header('location: /acme/products/');
            exit;
        } 
        else {
            $message = "<p>Failed to Delete $invName.</p>";
            $_SESSION['message'] = $message;
            header('location: /acme/products/');
            exit;
        }

        break;

    default:
        $products = getProductBasics();

        if (count($products) > 0) {
            $prodList = '<table>';
            $prodList .= '<thead>';
            $prodList .= '<tr><th>Product Name</th><td>&nbsp;</td><td>&nbsp;</td></tr>';
            $prodList .= '</thead>';
            $prodList .= '<tbody>';
            foreach ($products as $product) {
                $prodList .= "<tr><td>$product[invName]</td>";
                $prodList .= "<td><a href='/acme/products?action=mod&id=$product[invId]' title='Click to modify'>Modify</a></td>";
                $prodList .= "<td><a href='/acme/products?action=del&id=$product[invId]' title='Click to delete'>Delete</a></td></tr>";
            }
            $prodList .= '</tbody></table>';
        } else {
            $message = '<p class="notify">Sorry, no products were returned.</p>';
        }

        include "../view/product-management.php";
        break;
}