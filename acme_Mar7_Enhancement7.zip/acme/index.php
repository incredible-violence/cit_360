<?php

/*
 * ACME Controller
 */

// create or access a session
session_start();

// Get the database connection file
require_once 'library/connections.php';
// Get the acme model for use as needed
require_once 'model/acme-model.php';
// get the products model
require_once 'model/products-model.php';
// get the functions
require_once 'library/functions.php';

// Get the array of category Names
$categories = getCategories();

// $navList = createNav($categories);
$navList = createNav($categories);

if (isset($_SESSION['message'])) {
    $_SESSION['message'] = "";
}
if (isset($_COOKIE['firstname'])) {
    $cookieFirstname = filter_input(INPUT_COOKIE, 'firstname', FILTER_SANITIZE_STRING);
}

$action = filter_input(INPUT_POST, 'action');
if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
}

/* GOVERNANCE SWITCH */
switch ($action) {
    case 'template':
        include 'template/template.php';
        break;
    case 'login':
        include 'view/login.php';
        break;
    case 'register_form':
        include 'view/register.php';
        break;
    case 'register_user':
        echo 'register action';
        break;
    default:
        include 'view/home.php';
        break;
}