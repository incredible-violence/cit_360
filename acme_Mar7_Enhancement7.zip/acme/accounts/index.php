<?php

/*
 * Accounts Controller
 */

// create or access a session
session_start();

// Get the database connection file
require_once '../library/connections.php';
// Get the acme model for use as needed
require_once '../model/acme-model.php';
// get the accounts model
require_once '../model/accounts-model.php';
// get the functions library
require_once '../library/functions.php';

// Get the array of categories
$categories = getCategories();

// Build a navigation bar using the $categories array
$navList = createNav($categories);

// look for action
$action = filter_input(INPUT_POST, 'action');
if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
}


/* GOVERNANCE SWITCH */
switch ($action) {
    case 'login':
        include '../view/login.php';
        break;
    case 'login_user':

        $clientEmail = filter_input(INPUT_POST, 'clientEmail', FILTER_SANITIZE_EMAIL);
        $clientEmail = checkEmail($clientEmail);
        $clientPassword = filter_input(INPUT_POST, 'clientPassword', FILTER_SANITIZE_STRING);
        $passwordCheck = checkPassword($clientPassword);

        if (empty($clientEmail) || empty($passwordCheck)) {
            $_SESSION['message'] = '<p>ENTER A VALID EMAIL AND PASSWORD</p>';
            include '../view/login.php';
            exit;
        }

        // LOGIN PROCESSING
        // query client data
        $clientData = getClient($clientEmail);

        // compare hashes
        $hashCheck = password_verify($clientPassword, $clientData['clientPassword']);

        // on fail
        if (!$hashCheck) {
            $message = '<p class="notice">Please check your password and try again.</p>';
            include '../view/login.php';
            exit;
        }

        // SESSION MANAGEMENT
        // set loggedin state
        $_SESSION['loggedin'] = TRUE;

        // remove password from clientData [IMPORTANT FOR SECURITY - ONLY WORKS IF PASSWORD IS LAST ENTRY IN ARRAY]
        array_pop($clientData);
        $_SESSION['clientData'] = $clientData;


        // test for session
        //echo '<pre>' . print_r($_SESSION, true) . '</pre>';
        // display client data test
        // echo $_SESSION['clientData']['clientFirstname'] . ' ' . $_SESSION['clientData']['clientLastname'];
        // exit;
        // put various data from array into variables
        //$pageFName = $_SESSION['clientData']['clientFirstName'];
        //$pageLName = $_SESSION['clientData']['clientLastname'];
        //$pageEmail = $_SESSION['clientData']['clientEmail'];
        //$pagePrivi = $_SESSION['clientData']['clientLevel'];
        //echo $pageFName + $pageLName + $pageEmail + $pagePrivi;
        //exit;
        // REDIRECT
        include '../view/admin.php';
        // header('Location: ../view/admin.php');

        exit;
        break;

    case 'register_form':
        include '../view/register.php';
        break;
    case 'register_user':
        // echo 'register action';
        // SANITIZE INPUTS
        $clientFirstname = filter_input(INPUT_POST, 'clientFirstname', FILTER_SANITIZE_STRING);
        $clientLastname = filter_input(INPUT_POST, 'clientLastname', FILTER_SANITIZE_STRING);
        $clientEmail = filter_input(INPUT_POST, 'clientEmail', FILTER_SANITIZE_EMAIL);
        $clientPassword = filter_input(INPUT_POST, 'clientPassword', FILTER_SANITIZE_STRING);

        // VALIDATE EMAIL
        $clientEmail = checkEmail($clientEmail);

        // CHECK FOR EXISTING EMAIL
        $existingEmail = checkExistingEmail($clientEmail);

        if ($existingEmail) {
            $message = '<p class="notice">That email address already exists. Do you want to log in instead?</p>';
            include '../view/login.php';
            exit;
        }

        // VALIDATE PASSWORD
        $checkPassword = checkPassword($clientPassword);

        // CHECK FOR MISSING
        if (empty($clientFirstname) || empty($clientLastname) || empty($clientEmail) || empty($checkPassword)) {
            $message = '<p>Please provide information for all empty form fields.</p>';
            include '../view/register.php';
            exit;
        }

        // hash the password
        $hash = password_hash($clientPassword, PASSWORD_DEFAULT);

        // Send the data to the model
        $regOutcome = regClient($clientFirstname, $clientLastname, $clientEmail, $hash);

        // Check and report the result
        if ($regOutcome === 1) {
            // set cookie
            setcookie('firstname', $clientFirstname, strtotime('+1 year'), '/');

            // success message
            $_SESSION['message'] = "<p>Thank you for registering $clientFirstname. Please use your email and password to login.</p>";
            header('Location: /acme/accounts/?action=login');
            exit;
        } else {
            $message = "<p>Sorry $clientFirstname, but the registration failed. Please try again.</p>";
            include '../view/registration.php';
            exit;
        }
        break;

    case 'logout':
        session_destroy();
        session_unset();
        unset($_SESSION['loggedin']);
        $_SESSION = array();

        // header('Location: /acme/');
        include '../view/home.php';
        exit;

        break;
    case 'updateAcct':
        include '../view/client-update.php';
        break;
    case 'updateInfo':
        // get data
        $clientFirstname = filter_input(INPUT_POST, 'clientFirstname', FILTER_SANITIZE_STRING);
        $clientLastname = filter_input(INPUT_POST, 'clientLastname', FILTER_SANITIZE_STRING);
        $clientEmail = filter_input(INPUT_POST, 'clientEmail', FILTER_SANITIZE_EMAIL);
        $clientId = filter_input(INPUT_POST, 'clientId', FILTER_SANITIZE_NUMBER_INT);

        if (empty($clientFirstname) || empty($clientLastname) || empty($clientEmail)) {
            $message = '<p>Please provide information for all empty form fields.</p>';
            include '../view/client-update.php';
            exit;
        }

        $updateClient = upClient($clientFirstname, $clientLastname, $clientEmail, $clientId);

        if ($updateClient) {
            $message = "<p>Client $clientFirstname Updated</p>";
            $_SESSION['message'] = $message;
            header('location: /acme/accounts/');
            exit;
        } else {
            $message = "<p>Failed to Update $clientFirstname's Info.</p>";
            $_SESSION['message'] = $message;
            header('location: /acme/accounts/');
            exit;
        }
        break;
    case 'updatePassword':
        $clientPassword = filter_input(INPUT_POST, 'clientPassword', FILTER_SANITIZE_STRING);
        $clientId = filter_input(INPUT_POST, 'clientId', FILTER_SANITIZE_NUMBER_INT);

        $checkPassword = checkPassword($clientPassword);

        if (empty($checkPassword)) {
            $message = '<p>Please provide information for all empty form fields.</p>';
            include '../view/client-update.php';
            exit;
        }

        $hash = password_hash($clientPassword, PASSWORD_DEFAULT);
        
        $updatePassword = upPassword($hash, clientId);
        
        if ($updatePassword) {
            $message = "<p>Updated Password</p>";
            $_SESSION['message'] = $message;
            header('location: /acme/accounts/');
            exit;
        } else {
            $message = "<p>Failed to Update $clientFirstname Password.</p>";
            $_SESSION['message'] = $message;
            header('location: /acme/accounts/');
            exit;
        }
        break;

    default:
        header('Location: /acme/view/admin.php');
        break;
}